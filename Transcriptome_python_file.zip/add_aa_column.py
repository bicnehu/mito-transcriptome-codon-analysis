import pandas as pd
import os
files = os.listdir("./total_codon")
# Read your existing CSV
for file in files:
    print(file)
    df = pd.read_csv(f"./total_codon/{file}", header=None)

    # Your list to add
    amino_acids = [
        "K", "N", "K", "N", "T", "T", "T", "T", "R", "S", "R", "S",
        "I", "I", "M", "I", "Q", "H", "Q", "H", "P", "P", "P", "P",
        "R", "R", "R", "R", "L", "L", "L", "L", "E", "D", "E", "D",
        "A", "A", "A", "A", "G", "G", "G", "G", "V", "V", "V", "V",
        "*", "Y", "*", "Y", "S", "S", "S", "S", "*", "C", "W", "C",
        "L", "F", "L", "F"
    ]

    # Add the list as a new column (no header)
    df[len(df.columns)] = amino_acids

    # Save back without headers
    df.to_csv(f"./total_codon/{file}", index=False, header=False)
