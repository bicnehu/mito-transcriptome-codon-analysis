
import os

files_sk = os.listdir("./collect_fasta")
# print(files_sk)
orname =[]
for file_sk in files_sk:
    file = "./collect_fasta/"+file_sk
    temp_sk = file_sk.split(".")
    ofile = temp_sk[0]+"."+temp_sk[1]
    print(file)
    try:
        with open(file, 'r') as fh:
            data = fh.readlines()
    except IOError:
        print("Unable to open the file. Try again0.")
        exit()
    if(">" not in data[0]):
            print("Invalid input\nMissing '>' from your fasta file")
            exit()
    acc=[]
    gcc = []
    for i in data:
        if(">" in i):
            a = i.replace(">","").replace("\n","")
            acc.append(a)
    orname.append(acc)   
    

files_sk1 = os.listdir("./total_codon")
code=[]
codons = []
codname = ["AAA","AAC","AAG","AAT","ACA","ACC","ACG","ACT","AGA","AGC","AGG","AGT","ATA","ATC","ATG","ATT","CAA","CAC","CAG","CAT","CCA","CCC","CCG","CCT","CGA","CGC","CGG","CGT","CTA","CTC","CTG","CTT","GAA","GAC","GAG","GAT","GCA","GCC","GCG","GCT","GGA","GGC","GGG","GGT","GTA","GTC","GTG","GTT","TAA","TAC","TAG","TAT","TCA","TCC","TCG","TCT","TGA","TGC","TGG","TGT","TTA","TTC","TTG","TTT"]

for file_sk in files_sk1:
    file = "./total_codon/"+file_sk
    # temp_sk = file_sk.split(".")
    # ofile = temp_sk[0]
  
    try:
        with open(file, 'r') as fh:
            data = fh.readlines()
    except IOError:
        print("Unable to open the file. Try again2.")
        exit()
    
    for i in range(len(data)):
        a=data[i].split("\n")
        b=a[0].split(",")
        codons.append(b[1])
    code.append(codons)
    codons = []

final = open("heat_map.csv","w")
final.write(" ,")
for i in codname:
    final.write(f"{i},")
final.write("\n")
for i in range(len(orname)):
    cap = orname[i][0].capitalize()
    final.write(f"{cap},")
    for j in range(64):
        final.write(f"{code[i][j]},")
    final.write("\n")


    
        

