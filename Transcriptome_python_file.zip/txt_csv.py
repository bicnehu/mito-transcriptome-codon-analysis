import os

files = os.listdir("./cusp_out_all")

for file in files:
    FO = open(f"./cusp_out_all/{file}", "r")
    data = FO.readlines()
    FO.close()
    temp = file.split(".")
    FW = open(f"./cusp_csv/{temp[0]}.csv","w")
    for i in range(len(data)):
        if i > 6:
            if i == 7:
                a = data[i]
                b = a.split(" ")
                c = ",".join(b)
                FW.write(c)
            else:
                a = data[i]
                b = a.split("    ")
                c = ",".join(b)
                FW.write(c)
            #FW.write("\n")
    FW.close()
