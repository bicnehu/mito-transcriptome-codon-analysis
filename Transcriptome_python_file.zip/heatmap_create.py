import pandas as pd
import seaborn
import matplotlib.pyplot as plt
df = pd.read_csv("heat_map.csv")
df.set_index("organism_name", inplace=True)
# print(df)
ax=plt.figure(figsize=(50,50))
seaborn.heatmap(df,xticklabels=True,yticklabels=True,cmap='gist_rainbow')
# plt.figure(figsize=(20,20))
plt.savefig("heat_map.pdf")
#plt.show()
