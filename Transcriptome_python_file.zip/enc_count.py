import os
import math 
# from colorspacious import cspace_converter
skorganism = os.listdir("./out_csv")

w = open("enc_stat.csv","w")
for file in skorganism:
    print(file)
    orr = file.replace(".csv","")
    with open(f"./out_csv/{file}","r") as r:
        data = r.readlines()
    enc = []
    for i in data:
        a=i.split("\n")
        b=a[0].split(",")
        # print(b[1])
        try:
            enc.append(float(b[1]))
        except(ValueError):
            enc.append(0)
    meanENC = sum(enc)/len(enc)
    # print(meanAT)
    stENC = []
    for i in range(len(enc)):
        stENC.append((enc[i]-meanENC)**2)
        # print((AT[i]-meanAT)**2)

    sumENC = sum(stENC)

    w.write(f"{orr},{meanENC}±{math.sqrt(sumENC/(len(stENC)-1))}\n")
