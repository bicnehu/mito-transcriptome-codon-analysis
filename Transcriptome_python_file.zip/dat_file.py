import os

files = os.listdir("./order_cds")

for file in files:
    temp = file.split(".")
    os.system(f"cp ./order_cds/{file} ./dat_file/{temp[0]}.dat")
