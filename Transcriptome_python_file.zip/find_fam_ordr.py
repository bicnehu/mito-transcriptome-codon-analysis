from ete3 import NCBITaxa
import os
import re

# Initialize NCBI taxonomy database
ncbi = NCBITaxa()

def update_ncbi_taxonomy():
    """Ensure the local taxonomy database is up-to-date."""
    print("Updating local NCBI taxonomy database (this may take time)...")
    try:
        ncbi.update_taxonomy_database()
        print("✅ NCBI taxonomy database updated successfully.")
    except Exception as e:
        print(f"⚠️ Error updating NCBI taxonomy database: {e}")

def get_taxid_safely(organism_name):
    """Retrieve the taxonomic ID safely, trying different name variations."""
    try:
        # First try the original name
        taxid_dict = ncbi.get_name_translator([organism_name])
        if taxid_dict:
            return taxid_dict[organism_name][0]
        
        # Try lowercase
        taxid_dict = ncbi.get_name_translator([organism_name.lower()])
        if taxid_dict:
            return taxid_dict[organism_name.lower()][0]

        # Try search fallback
        search_results = ncbi.search_taxon(organism_name)
        if search_results:
            return search_results[0]  # Return best match
        
        return None
    except Exception as e:
        print(f"❌ Exception in get_taxid_safely for '{organism_name}': {e}")
        return None

def get_taxonomy_info(organism_name):
    """Retrieve genus, family, order, and class for a given organism name."""
    taxid = get_taxid_safely(organism_name)
    if not taxid:
        print(f"⚠️ Taxonomic ID not found for: {organism_name}")
        return "Not Found", "Not Found", "Not Found", "Not Found"
    
    try:
        lineage = ncbi.get_lineage(taxid)
        ranks = ncbi.get_rank(lineage)
        names = ncbi.get_taxid_translator(lineage)

        genus = next((names[t] for t, r in ranks.items() if r == 'genus'), 'Not Found')
        family = next((names[t] for t, r in ranks.items() if r == 'family'), 'Not Found')
        order = next((names[t] for t, r in ranks.items() if r == 'order'), 'Not Found')
        class_ = next((names[t] for t, r in ranks.items() if r == 'class'), 'Not Found')

        return genus, family, order, class_
    except Exception as e:
        print(f"❌ Error retrieving taxonomy for '{organism_name}': {e}")
        return "Not Found", "Not Found", "Not Found", "Not Found"

def clean_filename(filename):
    """
    Extract organism name from the filename in the format 'Genus_species'
    or similar substring anywhere in the filename.
    """
    match = re.search(r"([A-Za-z]+_[A-Za-z]+)", filename)
    return match.group(1).replace("_", " ") if match else "Unknown"

def main():
    """Main function to process files and extract taxonomy information."""
    update_ncbi_taxonomy()

    input_dir = "./collect_cds"
    output_file = "taxonomy.csv"

    if not os.path.isdir(input_dir):
        print(f"❌ Directory '{input_dir}' does not exist. Aborting.")
        return

    files = os.listdir(input_dir)
    if not files:
        print(f"⚠️ No files found in directory '{input_dir}'.")
        return

    with open(output_file, "w") as wh:
        wh.write("Organism,Genus,Family,Order,Class\n")  # Header line

        for file in files:
            organism = clean_filename(file)
            if organism == "Unknown":
                print(f"⚠️ Skipping file (organism name not found): {file}")
                continue

            print(f"🔍 Processing: {organism}")
            genus, family, order, class_ = get_taxonomy_info(organism)
            wh.write(f"{organism},{genus},{family},{order},{class_}\n")

    print(f"✅ Done. Taxonomy data written to '{output_file}'.")

if __name__ == "__main__":
    main()

