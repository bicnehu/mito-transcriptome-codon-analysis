#cusp -sequence NC_002529.fasta -outfile ../cusp_out_all/NC_002529.txt

import os

files = os.listdir("./collect_fasta")

for file in files:
    temp = file.split(".")
    os.system(f"cusp -sequence ./collect_fasta/{file} -outfile ./cusp_out_all/{temp[0]}.txt")
