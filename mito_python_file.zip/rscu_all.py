import os

# files_sk = os.listdir("../fasta")
# orname =[]

files_sk1 = os.listdir("./RSCU")
print(files_sk1)
# code=[]

# codname = []
# orname = []
final = open("rscu_map.csv","w")
# fi = open("../data/NC_00946.csv","r")
try:
    with open(f"./RSCU/{files_sk1[0]}", 'r') as fh:
        data3 = fh.readlines()
except IOError:
    print("Unable to open the file. Try again.")
    exit()

# print(codname)
for file_sk in files_sk1:
    codons = []
    file = "./RSCU/"+file_sk
    print(file)
    # temp_sk = file_sk.split(".")
    # ofile = temp_sk[0]
    orname = file_sk.replace(".tsv","")
    try:
        with open(file, 'r') as fh:
            data = fh.readlines()
    except IOError:
        print("Unable to open the file. Try again1.")
        exit()
    
    for i in range(len(data)):
        a=data[i].split("\n")
        b=a[0].split("\t")
        codons.append(b[3])
    codons.pop(0)
    # code.append(codons)
    # codons = []
    final.write(f"\n{orname},")
    for i in range(len(codons)):
        final.write(f"{codons[i]},")
    

# final = open("rscu_map.csv","w")
# final.write(" ,")
# for i in codname:
#     final.write(f"{i},")
# final.write("\n")
# for i in range(len(orname)):
#     final.write(f"{orname[i]},")
#     for j in range(64):
#         final.write(f"{code[i][j]},")
#     final.write("\n")


    
        

