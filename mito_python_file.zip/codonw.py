#codonw NC_014291.dat NC_014291.out NC_014291.blk -nomenu -silent -cai -enc -gc3s
import os

dat_fil = os.listdir("./dat_file")

for fil in dat_fil:
    tempa = fil.split(".")
    os.system(f"codonw ./dat_file/{fil} ./out/{tempa[0]}.out ./blk/{tempa[0]}.blk -nomenu -silent -cai -enc -gc3s")
