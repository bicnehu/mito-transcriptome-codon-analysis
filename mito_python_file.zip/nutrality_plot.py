import csv
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np
from matplotlib import ticker
import os

# Define the color for plotting
cl = "black"

def read_codon_data(filename):
    codon_data = {}
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            codon = row[0]
            frequency = int(row[1])
            codon_data[codon] = {'frequency': frequency}
    return codon_data

def calculate_gc_content(codon_data):
    gc1 = gc2 = gc3 = total_codons = 0
    for codon, data in codon_data.items():
        freq = data['frequency']
        if freq > 0:
            total_codons += freq
            if codon[0] in 'GC':
                gc1 += freq
            if codon[1] in 'GC':
                gc2 += freq
            if codon[2] in 'GC':
                gc3 += freq
    gc12 = (gc1 + gc2) / (2 * total_codons) if total_codons > 0 else 0
    gc3 = gc3 / total_codons if total_codons > 0 else 0
    return gc12, gc3

def plot_neutrality(gc12_values, gc3_values):
    tick_spacing = 0.2
    tick_spacing1 = 0.2
    plt.figure(figsize=(6, 6))
    ax = plt.axes()
    ax.scatter(gc3_values, gc12_values, s=2, color=cl)

    # Perform linear regression
    slope, intercept, r_value, p_value, std_err = stats.linregress(gc3_values, gc12_values)
    line = slope * np.array(gc3_values) + intercept
    ax.plot(gc3_values, line, color='red', linewidth=3)

    # Print regression analysis details
    print(f'Slope: {slope}')
    print(f'Intercept: {intercept}')
    print(f'R-squared: {r_value**2}')
    print(f'P-value: {p_value}')
    print(f'Standard error: {std_err}')

    # Add regression equation and R^2 value to the plot
    plt.text(0.2, 0.7, f'y={slope:.4f}x+{intercept:.4f}\n$R^2$={r_value**2:.8f}', fontsize=10, color='black')
    plt.xlim(0.0, 0.6)
    plt.ylim(0.0, 0.8)
    ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_spacing1))
    plt.xlabel('GC3')
    plt.ylabel('GC12')
    plt.title('Neutrality Plot (GC12 vs. GC3)')
    plt.grid()
    plt.savefig(f"nutrality.svg")
    plt.show()

# Main script
GC12 = []
GC3 = []

# List files in the directory
skorganism = os.listdir("./codon_count")

# Loop through all files and read the data
for organisms_sk in skorganism:
    file_path = f'./codon_count/{organisms_sk}'
    codon_data = read_codon_data(file_path)
    gc12, gc3 = calculate_gc_content(codon_data)
    GC12.append(gc12)
    GC3.append(gc3)

# Debug plot to visualize raw data points
plt.figure(figsize=(5, 5))
plt.scatter(GC3, GC12, color=cl)
plt.xlabel('GC3')
plt.ylabel('GC12')
plt.title('Raw Data Plot (GC12 vs. GC3)')
plt.show()

# Plot the neutrality plot
plot_neutrality(GC12, GC3)
