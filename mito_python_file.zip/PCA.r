# Load necessary packages
library(FactoMineR)
library(factoextra)
library(ggplot2)
library(ggrepel)

# Read the data (update the file path as needed)
data <- read.csv("./rscu_map.csv", header = TRUE, sep = ",")

# Check for missing values
if (any(is.na(data))) {
  stop("The dataset contains missing values. Please clean the data and try again.")
}

# Ensure the first column is treated as a factor
data$TaxonomicOrder <- as.factor(data$TaxonomicOrder)

# Perform PCA
res.pca <- PCA(data[, -1], scale.unit = TRUE, graph = FALSE)

# Extract PCA results
pca_data <- as.data.frame(res.pca$ind$coord)
pca_data$TaxonomicOrder <- data$TaxonomicOrder

# Define colors (handling if there are more unique orders than colors)
orders <- unique(pca_data$TaxonomicOrder)
codon_colors <- rainbow(length(orders))
colors <- setNames(codon_colors, orders)

# Check for missing values in PCA results
if (any(is.na(pca_data))) {
  stop("PCA results contain missing values. This might be due to zero variance in some variables.")
}

# Open a plotting device (e.g., PDF)
pdf("./PCA_Codon_Usage_final.pdf", width = 8, height = 6)

# Create the plot using fviz_pca_biplot with adjusted settings
p <- fviz_pca_biplot(res.pca, 
                     geom.ind = "point", 
                     col.ind = pca_data$TaxonomicOrder,
                     palette = colors,
                     addEllipses = TRUE,
                     ellipse.type = "t",  # Change ellipse type to "t"
                     ellipse.level = 0.95,  # Set ellipse level (confidence level)
                     label = "var", 
                     col.var = "grey",
                     repel = TRUE) +
      theme_minimal() +
      labs(title = "PCA of Codon Usage", 
           x = paste0("Dim1 (", round(res.pca$eig[1,2], 1), "%)"), 
           y = paste0("Dim2 (", round(res.pca$eig[2,2], 1), "%)")) +
      theme(legend.position = "right", 
            legend.title = element_blank())

# Print the plot to the plotting device
print(p)

# Save the plot (automatically saves to the open plotting device)
dev.off()
