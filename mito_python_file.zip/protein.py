import os

# Get the list of files in the specified directory
files_sk = os.listdir("./collect_cds")

# Define the list of common genes and their descriptions
cmngene = {
    'ATP6': 'ATP synthase subunit 6',
    'ATP8': 'ATP synthase subunit 8',
    'COX1': 'Cytochrome c oxidase subunit I',
    'COX2': 'Cytochrome c oxidase subunit II',
    'COX3': 'Cytochrome c oxidase subunit III',
    'COB': 'Cytochrome b',
    'NAD1': 'NADH dehydrogenase subunit 1',
    'NAD2': 'NADH dehydrogenase subunit 2',
    'NAD3': 'NADH dehydrogenase subunit 3',
    'NAD4': 'NADH dehydrogenase subunit 4',
    'NAD4L': 'NADH dehydrogenase subunit 4L',
    'NAD5': 'NADH dehydrogenase subunit 5',
    'NAD6': 'NADH dehydrogenase subunit 6'
}

for file_sk in files_sk:
    file = os.path.join("./collect_cds", file_sk)
    temp_sk = file_sk.split(".")
    ofile = temp_sk[0]
    
    try:
        with open(file, 'r') as fh:
            data = fh.read()
    except IOError:
        print("Unable to open the file. Try again.")
        exit()
    
    
    data = data.upper()
    entries = data.split(">")
    
    seq = []
    gen = []
    
    for entry in entries:
        print(entry)
        if "[GENE=CO1" in entry:
            entry = entry.replace("[GENE=CO1", "[GENE=COX1")
        if "[GENE=CO2" in entry:
            entry = entry.replace("[GENE=CO2", "[GENE=COX2")
        if "[GENE=CO3" in entry:
            entry = entry.replace("[GENE=CO3", "[GENE=COX3")
        if "[GENE=ND" in entry:
            entry = entry.replace("[GENE=ND", "[GENE=NAD")
        if "[GENE=CYTB" in entry:
            entry = entry.replace("[GENE=CYTB", "[GENE=COB")
        if "[PROTEIN=ATP" in entry and "SUBUNIT 6" in entry:
            entry = entry.replace("[PROTEIN=ATP", "[GENE=ATP6")
        if "[PROTEIN=ATP" in entry and "SUBUNIT 8" in entry:
            entry = entry.replace("[PROTEIN=ATP", "[GENE=ATP8")
        if "[PROTEIN=CYTOCHROME" in entry and "SUBUNIT I" in entry:
            entry = entry.replace("SUBUNIT I]", "[GENE=COX1")
        if "[PROTEIN=CYTOCHROME" in entry and "SUBUNIT II" in entry:
            entry = entry.replace("SUBUNIT II]", "[GENE=COX2")
        if "[PROTEIN=CYTOCHROME" in entry and "SUBUNIT III" in entry:
            entry = entry.replace("SUBUNIT III]", "[GENE=COX3")
        if "[PROTEIN=CYTOCHROME B" in entry:
            entry = entry.replace("[PROTEIN=CYTOCHROME B", "[GENE=COB")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 1" in entry:
            entry = entry.replace("[PROTEIN=NADH", "[GENE=NAD1")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 2" in entry:
            entry = entry.replace("[PROTEIN=NADH", "[GENE=NAD2")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 3" in entry:
            entry = entry.replace("[PROTEIN=NADH", "[GENE=NAD3")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 4]" in entry:
            entry = entry.replace("SUBUNIT 4]", "[GENE=NAD4")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 5" in entry:
            entry = entry.replace("[PROTEIN=NADH", "[GENE=NAD5")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 6" in entry:
            entry = entry.replace("[PROTEIN=NADH", "[GENE=NAD6")
        if "[PROTEIN=NADH" in entry and "SUBUNIT 4L]" in entry:
            entry = entry.replace("SUBUNIT 4L]", "[GENE=NAD4L")
        if any(gene in entry for gene in cmngene):
            spl = entry.split(" ")
            gen.append(spl[1])
            seq.append(entry)
    
    array = []
    for i in range(len(seq)):
        array.append(f">{gen[i]} {seq[i]}\n")
    
    array.sort()
    
    gene_dict = {gene: "" for gene in cmngene}
    
    for i in array:
        for gene in cmngene:
            if gene in i:
                gene_dict[gene] = i
    
    output_lines = []
    for gene, description in cmngene.items():
        if gene_dict[gene] == "":
            output_lines.append(f">[GENE={gene}]\n\n")
        else:
            output_lines.append(gene_dict[gene])
    
    output_file_path = f"./protein_cds/{ofile}.fasta"
    with open(output_file_path, "w") as output_file:
        for line in output_lines:
            output_file.write(line)

print("Process completed successfully.")
