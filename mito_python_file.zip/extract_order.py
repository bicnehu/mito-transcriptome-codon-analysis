import requests
file = "./taxonomy.csv"
try:
    with open(file, 'r') as fh:
        data1 = fh.readlines()
except IOError:
    print("Unable to open the file. Try again.")
    exit()
data1.pop(0)
nc = []
fam =[]
for i in range(len(data1)):
    a=data1[i].split("\n")
    b=a[0].split(",")
    c = b[0].replace('"','')
    nc.append(c)
    d = b[3].replace('"','')
    fam.append(d)
    
di = zip(nc,fam)
di = dict(di)

dic = {}
for key, value in di.items():
    if value not in dic:
        dic[value] = []
    dic[value].append(key)

key = dic.keys()
value = dic.values()
key = list(key)
value = list(value)
# print(value)
for i in range(len(value)):
    print(key[i])
    FO = open(f"./order_cds/{key[i]}.fasta","a")
    for j in value[i]:
        r = open(f"./collect_cds/{j}_cds.fasta","r")
        data = r.read()
        FO.write(data)
       
