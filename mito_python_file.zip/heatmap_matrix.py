import os
files_sk1 = os.listdir("./cusp_csv")
code=[]
codons = []
# codname = ["AAA","AAC","AAG","AAT","ACA","ACC","ACG","ACT","AGA","AGC","AGG","AGT","ATA","ATC","ATG","ATT","CAA","CAC","CAG","CAT","CCA","CCC","CCG","CCT","CGA","CGC","CGG","CGT","CTA","CTC","CTG","CTT","GAA","GAC","GAG","GAT","GCA","GCC","GCG","GCT","GGA","GGC","GGG","GGT","GTA","GTC","GTG","GTT","TAA","TAC","TAG","TAT","TCA","TCC","TCG","TCT","TGA","TGC","TGG","TGT","TTA","TTC","TTG","TTT"]
# fi = open("../data/NC_00946.csv","r")
# try:
#     with open(f"../total_codon/{id}.csv", 'r') as fh:
#         data3 = fh.readlines()
# except IOError:
#     print("Unable to open the file. Try again1.")
#     exit()
# for i in range(len(data3)):
#     a=data3[i].split("\n")
#     b=a[0].split(",")
#     codname.append(b[0])s
# print(codname)
codname = []

final = open("heat_map.csv","w")
# final.write(",")
for file_sk in files_sk1:
    print(file_sk)
    orn = file_sk.split(".")
    
    file = "./cusp_csv/"+file_sk
    # temp_sk = file_sk.split(".")
    # ofile = temp_sk[0]
    
    try:
        with open(file, 'r') as fh:
            data = fh.readlines()
    except IOError:
        print("Unable to open the file. Try again2.")
        exit()
    data.pop(0)
    for i in range(len(data)):
        a=data[i].split("\n")
        b=a[0].split(",")
        codname.append(b[0])
        try:
            codons.append(b[4])
        except(IndexError):
            # c = b[3].split("   ")
            try:
                codons.append(b[3])
            except(IndexError):
                c = b[2].split("   ")
                codons.append(c[2])


       
 
    
    # for i in codname:
    #     final.write(f"{i},")
    final.write(f"{orn[0].capitalize()},")
    for j in codons:
        final.write(f"{j},")
    final.write("\n")
    codons = []







    
        

