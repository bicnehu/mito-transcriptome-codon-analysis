import os
files = os.listdir("./cusp_csv")
for file in files:
    with open(f"./cusp_csv/{file}","r") as r:
        data = r.readlines()
    w = open(f"./cusp_file/{file}","w")
    for i in data:
        if "   " in i:
            a = i.replace("   ",",")
            w.write(f"{a}")
        else:
            w.write(i)
