import csv
import os

files_sk = os.listdir("./cusp_file")

for file_sk in files_sk:
    file = file_sk
    temp_sk = file.split(".")
    print(temp_sk)
    ofile = f"./RSCU/{temp_sk[0]}.tsv"
    # Read the data from the CSV file
    with open("./cusp_file/"+file, "r") as r:
        data = r.readlines()

    # Remove the header
    data.pop(0)

    # Initialize lists to store data
    codon = []
    number1 = []
    aa = []

    # Parse the data
    for line in data:
        a = line.split(",")
        codon.append(a[0].strip())
        aa.append(a[1].strip())
        number1.append(int(a[-1].strip()))

    # Initialize dictionaries to store totals and counts
    total_counts = {}
    codon_counts = {}

    # Calculate total and counts per amino acid
    for i in range(len(aa)):
        amino_acid = aa[i]
        number = number1[i]
        if amino_acid not in total_counts:
            total_counts[amino_acid] = 0
            codon_counts[amino_acid] = 0
        total_counts[amino_acid] += number
        codon_counts[amino_acid] += 1

    # Initialize a list to store the results
    results = []

    # Calculate expected values and RSCU
    for i in range(len(codon)):
        codon_val = codon[i]
        aa_val = aa[i]
        number_val = number1[i]
        total = total_counts[aa_val]
        num_codons = codon_counts[aa_val]
        expected = total / num_codons
        rscu = number_val / expected
        results.append([codon_val, aa_val, number_val, rscu])

    # Write the results to a TSV file
    with open(ofile, 'w', newline='') as tsvfile:
        writer = csv.writer(tsvfile, delimiter='\t')
        writer.writerow(['Codon', 'AA', 'Number', 'RSCU'])
        writer.writerows(results)

# Display the results
# for row in results:
#     print(row)
