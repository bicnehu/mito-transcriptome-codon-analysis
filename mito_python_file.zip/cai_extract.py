import os

files = os.listdir("./out_csv_cai")
w=open("cai_all.csv","w")
for file in files:
    r=open(f"./out_csv_cai/{file}","r")
    a=r.readlines()
    cai=[]
    w.write(f"{file},")
    for i in a:
        b= i.split(",")
        print(b)
        w.write(f"{b[1]},")

    w.write(f"\n")
    
    
    