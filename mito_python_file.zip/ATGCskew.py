import matplotlib.pyplot as plt
from matplotlib import ticker
import os
import numpy as np
import csv
from matplotlib.patches import Ellipse
import matplotlib.transforms as transforms
# from colorspacious import cspace_converter
skorganism = os.listdir("./sequence")
AT = []
GC = []
GC31 = []
orr=[]
w = open("ATGCskew.csv","w")
for organisms_sk in skorganism:
    orname = organisms_sk
    orr.append(orname)
    temp_sk = os.listdir("./sequence/"+orname)
    cds = len(temp_sk)
    #cl = input("Enter the color:")
    g3 = []
    a3 = []
    
    for i in range(0, cds):
        with open(f"./sequence/{orname}/{orname}_{i}.fasta", "r") as r:
            data = r.read()
    
        # data.pop(0)  # Remove header
    
        G3_count = data.count("G")
        A3_count = data.count("A")
        T3_count = data.count("T")
        C3_count = data.count("C")
    
        # for line in data:
        #     codon, count = line.strip().split(",")
        #     count = int(count)
    
        #     if codon[-1] == 'G':
        #         G3_count += count
        #     if codon[-1] == 'A':
        #         A3_count += count
        #     if codon[-1] == 'T':
        #         T3_count += count
        #     if codon[-1] == 'C':
        #         C3_count += count
        # print(G3_count + C3_count)
        # print(C3_count)
        G3_C3_ratio = (G3_count-C3_count) / (G3_count + C3_count) if G3_count + C3_count > 0 else 0
        A3_T3_ratio = (A3_count-T3_count) / (A3_count + T3_count) if A3_count + T3_count > 0 else 0
        # ratio = A3_T3_ratio/G3_C3_ratio 
        a3.append(A3_T3_ratio)
        g3.append(G3_C3_ratio)
        w.write(f"{orname}_{i},{A3_T3_ratio},{G3_C3_ratio}\n")
    AT.append(a3)
    GC.append(g3)
    # def read_codon_data(filename):
    #     codon_data = {}
    #     with open(filename, 'r') as file:
    #         reader = csv.reader(file)
    #         next(reader)  # Skip header
    #         for row in reader:
    #             codon = row[0]
    #             frequency = int(row[1])
    #             #fraction = float(row[2])
    #             codon_data[codon] = {'frequency': frequency}
    #     return codon_data
    # def confidence_ellipse(x, y, ax, n_std=1.0, facecolor='none', **kwargs):
    #     if x.size != y.size:
    #         raise ValueError("x and y must be the same size")

    #     cov = np.cov(x, y)
    #     pearson = cov[0, 1] / np.sqrt(cov[0, 0] * cov[1, 1])
    #     ell_radius_x = np.sqrt(1 + pearson)
    #     ell_radius_y = np.sqrt(1 - pearson)
    #     ellipse = Ellipse((0, 0), width=ell_radius_x * 2, height=ell_radius_y * 2, facecolor=facecolor, **kwargs)

    #     scale_x = np.sqrt(cov[0, 0]) * n_std
    #     mean_x = np.mean(x)

    #     scale_y = np.sqrt(cov[1, 1]) * n_std
    #     mean_y = np.mean(y)

    #     transf = transforms.Affine2D().rotate_deg(45).scale(scale_x, scale_y).translate(mean_x, mean_y)
    #     ellipse.set_transform(transf + ax.transData)
    #     return ax.add_patch(ellipse)

    # def calculate_gc_content(codon_data):
    #     gc3 = total_codons = 0
    #     for codon, data in codon_data.items():
    #         freq = data['frequency']
    #         if freq > 0:
    #             total_codons += freq
                
    #             if codon[2] in 'GC':
    #                 gc3 += freq
        
    #     gc3 = gc3
    #     return gc3
    # GC3 = []
    # for i in range(0, cds):
    #     file_path = f'../codon_count/{orname}/{orname}_{i}.csv'
    #     codon_data = read_codon_data(file_path)
    #     gc3 = calculate_gc_content(codon_data)
    #     # GC12.append(gc12)
    #     GC3.append(gc3)
    # GC31.append(GC3)
    # print(a3)
    # 
# AT.pop(-1)
# AT.pop(-1)
# GC31.pop(-1)
# GC31.pop(-1)
# print(AT)
cl = beautiful_distinct_colors = [
    "#1F618D",  # Dark Blue
    "#16A085",  # Teal
    "#E74C3C",  # Crimson Red
    "#8E44AD",  # Purple
    "#F39C12",  # Bright Orange
    "#2C3E50",  # Midnight Blue
    "#27AE60",  # Green
    "#C0392B",  # Deep Red
    "#2980B9",  # Sky Blue
    "#D35400",  # Rust Orange
    "#9B59B6",  # Lavender
    "#F1C40F",  # Yellow
    "#7D3C98",  # Dark Violet
    "#D4AC0D",  # Mustard Yellow
    "#2E86C1",  # Bright Blue
    "#CA6F1E",  # Burnt Orange
    "#145A32",  # Dark Green
    "#5D6D7E"   # Slate Gray
]




plt.figure(figsize=(11,11))
ax = plt.axes()
plt.grid()
# plt.figure(figsize=(20,20))
# plt.style.use('dark_background')
for i in range(len(GC)):
    xi = GC[i]
    yi = AT[i]
    colors = np.random.rand(len(xi), 3)
    ax.scatter(xi, yi, marker='.', color = cl[i], label=f"{orr[i]}")
    # confidence_ellipse(np.array(xi), np.array(yi), ax, edgecolor=colors)

# Customize the plot
# plt.xlim(-0.3,0.5)
# plt.ylim(-0.3,0.4)
plt.xlabel("GC skew")
plt.ylabel("AT skew")
plt.legend(loc='best',framealpha=1)
plt.savefig("AT-GC_plot.svg")
plt.show()