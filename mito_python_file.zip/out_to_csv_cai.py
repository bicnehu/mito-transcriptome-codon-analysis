import os

files = os.listdir("./out_cai")

for file in files:
    FO = open(f"./out_cai/{file}", "r")
    data = FO.readlines()
    FO.close()
    temp = file.split(".")
    FW = open(f"./out_csv_cai/{temp[0]}.csv","w")
    for i in range(len(data)):
        if i > 0:
            a = data[i]
            b = a.split("\t")
            # b.pop(0)
            c = ",".join(b)
            FW.write(c)
            #FW.write("\n")
    FW.close()
