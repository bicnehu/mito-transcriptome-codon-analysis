import os

files = os.listdir("./protein_cds")

for file in files:
    temp = file.split(".")
    os.system(f"cp ./protein_cds/{file} ./dat_file_cai/{temp[0]}.dat")
