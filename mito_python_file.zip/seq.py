import os

files_sk = os.listdir("./order_cds")

for file_sk in files_sk:
    file = "./order_cds/"+file_sk.replace(" ","")
    temp_sk = file_sk.split(".")
    ofile = temp_sk[0].strip()
    print(ofile)
    try:
        with open(file, 'r') as fh:
            data = fh.readlines()
    except IOError:
        print("Unable to open the file. Try again.")
        exit()
    if(">" not in data[0]):
            print("Invalid input\nMissing '>' from your fasta file")
            exit()
    acc=[]
    for i in data:
        if(">" in i):
            try:
                a = i.split(">")
                acc.append(a[1].replace("\n",""))
            except(IndexError):
                a = i.split("\n")
                acc.append(a[0])
        
    
    pos=[]
    for i in range(len(data)):
        if(">" in data[i]):
            pos.append(i)
    pos.append(len(data))
    
    seq = []
    
    for i in range(len(pos)-1):   
        for j in range(pos[i]+1,pos[i+1]):
            seq.append(data[j])
        seq.append("\t")
    
    dna_list=[]
    gr=[]
    for i in seq:
        if i != "\t":
            gr.append(i)
        else:
            dna_list.append("".join(gr).replace(' ', '').replace('\n', ''))
            gr=[]
    if gr:
        dna_list.append("".join(gr).replace(' ', '').replace('\n', ''))
    
    os.mkdir(f"./sequence/{ofile}") 
    for i in range(len(acc)):
        
        dna_sequence = dna_list[i]
        # codon_freq = calculate_codon_frequency(dna_sequence)
        # cd = []
        # fr = []
        a = open(f"./sequence/{ofile}/{ofile}_{i}.fasta","w")
        # Print the codon frequencies
        # for codon, freq in sorted(codon_freq.items()):
            # cd.append(codon)
            # fr.append(freq)
        a.write(f">{ofile}_{i}\n{dna_sequence}")
            
    
