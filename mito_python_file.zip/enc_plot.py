import matplotlib.pyplot as plt
from matplotlib import ticker
import os
import numpy as np
import csv
from matplotlib.patches import Ellipse
import matplotlib.transforms as transforms
# from colorspacious import cspace_converter
skorganism = os.listdir("./out_csv")
AT = []
GC3 = []
ENC = []
orr=[]
# w = open("enc_gc3_cai")
for organisms_sk in skorganism:
    orname = organisms_sk
    # print(orname)
    orr.append(orname.replace(".csv",""))
    print(orname)
    # temp_sk = os.listdir("../out_csv_final/"+orname)
    # cds = len(temp_sk)
    #cl = input("Enter the color:")
    gc3 = []
    enc = []
    
    # for i in range(0, cds):
    with open(f"./out_csv/{orname}", "r") as r:
        data = r.readlines()
        # data.pop(0)  # Remove header

    for i in range(len(data)):
        a=data[i].split("\n")
        b=a[0].split(",")
        gc3.append(float(b[2]))
        try:
            enc.append(float(b[1]))
        except(ValueError):
            enc.append(0)
        
    GC3.append(gc3)
    ENC.append(enc)

# Example 2D array

# Flatten the 2D array using list comprehension
GC31 = [element for sublist in GC3 for element in sublist]

# print(GC31)
def expected_ENc(GC3s):
    return 2 + GC3s + 29 / (GC3s**2 + (1 - GC3s)**2)
    
GC3s = np.linspace(0, 1, 100)
ENc = expected_ENc(GC3s)
cl = beautiful_distinct_colors = [
    "#1F618D",  # Dark Blue
    "#16A085",  # Teal
    "#E74C3C",  # Crimson Red
    "#8E44AD",  # Purple
    "#F39C12",  # Bright Orange
    "#2C3E50",  # Midnight Blue
    "#27AE60",  # Green
    "#C0392B",  # Deep Red
    "#2980B9",  # Sky Blue
    "#D35400",  # Rust Orange
    "#9B59B6",  # Lavender
    "#F1C40F",  # Yellow
    "#7D3C98",  # Dark Violet
    "#D4AC0D",  # Mustard Yellow
    "#2E86C1",  # Bright Blue
    "#CA6F1E",  # Burnt Orange
    "#145A32",  # Dark Green
    "#5D6D7E"   # Slate Gray
]




w = open("colors.csv","w")
tick_spicing = 10
tick_spicing1 = 0.2
plt.figure(figsize=(11,11))
ax = plt.axes()
# colors = [color for _, color in cl]
for i in range(len(GC3)):
    xi = GC3[i]
    yi = ENC[i]
    ax.scatter(xi, yi, marker='.', color = cl[i], label=f"{orr[i]}")
    w.write(f"{cl[i]},{orr[i]}\n")
    


ax.plot(GC3s, ENc, label='Expected ENc', color='black')
ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_spicing))
ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_spicing1))
plt.xlim(0.0,1.0)
plt.ylim(20,70)
# plt.title("Vaccine")
plt.xlabel("GC3s")
plt.ylabel("ENc")
plt.legend(loc='best',framealpha=1)
plt.savefig(f"enc_final_graph.svg")
plt.show()