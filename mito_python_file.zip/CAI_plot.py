import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import matplotlib.transforms as mtransforms
# File name
file = "CAI.csv"

# Reading the file
try:
    with open(file, 'r') as fh:
        data1 = fh.readlines()
except IOError:
    print("Unable to open the file. Try again.")
    exit()

# Gene list
gene = [
    "ATP6", "ATP8", "COX1", "COX2", "COX3", "COB", "NAD1", 
    "NAD2", "NAD3", "NAD4", "NAD4L", "NAD5", "NAD6"
]

# Extracting data
order = []
for i in range(len(data1)):
    a = data1[i].split("\n")
    b = a[0].split(",")
    if "ï»¿" in b[0]:
        b[0] = b[0].replace("ï»¿", "")
    order.append(b[0])

yax = []
odr = []
for i in range(len(order)):
    a = data1[i].split(",")
    b = a.pop(0)
    if "ï»¿" in b:
        b = b.replace("ï»¿", "")
    odr.append(b)
    a[-1] = a[-1].replace("\n", "")
    a = [float(j) for j in a]
    yax.append(a)

# Generate smooth curves
x = np.arange(len(gene))
xnew = np.linspace(x.min(), x.max(), 300)  # 300 represents the number of points to interpolate

plt.figure(figsize=(12, 8))

for y, label in zip(yax, odr):
    spline = make_interp_spline(x, y, k=3)  # k=3 represents cubic spline
    y_smooth = spline(xnew)
    plt.plot(xnew, y_smooth, label=label)

# Plotting
plt.xlabel('Gene')
plt.ylabel('CAI')  # Gene expression values on the y-axis
plt.xticks(ticks=x, labels=gene, rotation=90)
plt.grid(True)
plt.tight_layout()
plt.legend(loc='best', framealpha=1)
# legend_box = legend.get_frame()
# # Save and show the plot
# rotation_transform = mtransforms.Affine2D().rotate_deg(90)

# # Apply the rotation to the legend box
# legend_box.set_transform(rotation_transform + plt.gca().transAxes)
plt.savefig("CAI_plot_smooth.svg")
plt.show()